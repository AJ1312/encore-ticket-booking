'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Bell, Clock, Sparkles, CheckCircle2, Ticket, X, ChevronRight, LogIn } from 'lucide-react';
import { apiJson } from '@/lib/api';
import type { Session } from '@encore/shared';

export type AppNotification = {
  id: string;
  type: 'hold_warning' | 'waitlist_offer' | 'booking_confirmed' | 'seat_opened';
  title: string;
  message: string;
  timestamp: string;
  link: string;
  unread: boolean;
};

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const menuRef = useRef<HTMLDivElement>(null);

  function syncUserAndNotifications() {
    try {
      const storedProfile = window.localStorage.getItem('encore_profile');
      if (storedProfile) {
        setSession(JSON.parse(storedProfile) as Session);
      } else {
        setSession(null);
      }

      // Check stored custom user notifications
      const storedNotifs = window.localStorage.getItem('encore_user_notifications');
      if (storedNotifs && storedProfile) {
        setNotifications(JSON.parse(storedNotifs) as AppNotification[]);
        return;
      }
    } catch {
      // ignore
    }

    // Verify session with server authority
    apiJson<{ session?: Session; user?: Session }>('/auth/me')
      .then(res => {
        const active = res.session || res.user;
        if (active) {
          setSession(active);
          // If logged in, fetch user's real bookings to construct notification list
          apiJson<{ bookings: Array<{ bookingRef: string; eventTitle?: string; status: string; createdAt?: string }> }>('/bookings')
            .then(bRes => {
              if (bRes.bookings && bRes.bookings.length > 0) {
                const notifs: AppNotification[] = bRes.bookings.map(b => ({
                  id: `notif-${b.bookingRef}`,
                  type: 'booking_confirmed',
                  title: 'Booking Confirmed',
                  message: `Your ticket pass for ${b.eventTitle || 'your event'} is confirmed. Present QR at gate.`,
                  timestamp: 'Recent',
                  link: `/booking/${b.bookingRef}/confirmation`,
                  unread: false,
                }));
                setNotifications(notifs);
              } else {
                setNotifications([]);
              }
            })
            .catch(() => {
              setNotifications([]);
            });
        } else {
          setSession(null);
          setNotifications([]);
        }
      })
      .catch(() => {
        setSession(null);
        setNotifications([]);
      });
  }

  useEffect(() => {
    syncUserAndNotifications();

    const handleProfileUpdate = () => syncUserAndNotifications();
    const handleNotificationAdded = (e: Event) => {
      try {
        const customEvt = e as CustomEvent<AppNotification>;
        if (customEvt.detail) {
          setNotifications(prev => [customEvt.detail, ...prev.filter(n => n.id !== customEvt.detail.id)]);
        } else {
          syncUserAndNotifications();
        }
      } catch {
        syncUserAndNotifications();
      }
    };

    window.addEventListener('profile-updated', handleProfileUpdate);
    window.addEventListener('notification-added', handleNotificationAdded);
    window.addEventListener('storage', handleProfileUpdate);

    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      window.removeEventListener('profile-updated', handleProfileUpdate);
      window.removeEventListener('notification-added', handleNotificationAdded);
      window.removeEventListener('storage', handleProfileUpdate);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const unreadCount = session ? notifications.filter(n => n.unread).length : 0;

  function markAllRead() {
    setNotifications(prev => {
      const updated = prev.map(n => ({ ...n, unread: false }));
      try {
        window.localStorage.setItem('encore_user_notifications', JSON.stringify(updated));
      } catch {
        // ignore
      }
      return updated;
    });
  }

  function dismiss(id: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    setNotifications(prev => {
      const filtered = prev.filter(n => n.id !== id);
      try {
        window.localStorage.setItem('encore_user_notifications', JSON.stringify(filtered));
      } catch {
        // ignore
      }
      return filtered;
    });
  }

  return (
    <div ref={menuRef} style={{ position: 'relative', display: 'inline-block' }}>
      <button
        type="button"
        onClick={() => setOpen(prev => !prev)}
        aria-label={`Notifications (${unreadCount} unread)`}
        style={{
          position: 'relative',
          background: open ? '#2a1a14' : '#1c1513',
          border: `1.5px solid ${unreadCount > 0 ? 'var(--coral)' : '#523d32'}`,
          borderRadius: 999,
          padding: '7px 14px',
          display: 'flex',
          alignItems: 'center',
          gap: 7,
          color: 'var(--peach)',
          cursor: 'pointer',
          boxShadow: unreadCount > 0 ? '0 0 14px rgba(224, 122, 95, 0.25)' : 'none',
          transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      >
        <Bell size={16} color="var(--coral)" style={{ animation: unreadCount > 0 ? 'pulse 2s infinite' : 'none' }} />
        <span style={{ font: '11px var(--mono)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          Alerts
        </span>
        {unreadCount > 0 && (
          <span
            style={{
              background: 'var(--coral)',
              color: '#ffffff',
              fontSize: 10,
              fontWeight: 700,
              padding: '1px 6px',
              borderRadius: 999,
              lineHeight: 1.3,
            }}
          >
            {unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 10px)',
            right: 0,
            width: 340,
            background: '#16191c',
            border: '1px solid #3d342f',
            borderRadius: 8,
            boxShadow: '0 20px 50px rgba(0,0,0,0.7)',
            zIndex: 1000,
            overflow: 'hidden',
          }}
        >
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '14px 16px',
              borderBottom: '1px solid #282b30',
              background: '#131517',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <strong style={{ font: '13px var(--mono)', color: 'var(--paper)', textTransform: 'uppercase' }}>
                Notifications
              </strong>
              {unreadCount > 0 && (
                <span
                  style={{
                    background: '#3d241c',
                    color: 'var(--coral)',
                    fontSize: 10,
                    padding: '2px 6px',
                    borderRadius: 999,
                    fontWeight: 600,
                  }}
                >
                  {unreadCount} new
                </span>
              )}
            </div>
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={markAllRead}
                style={{
                  background: 'transparent',
                  border: 0,
                  color: 'var(--muted)',
                  fontSize: 11,
                  font: '10px var(--mono)',
                  cursor: 'pointer',
                  textTransform: 'uppercase',
                }}
              >
                Mark all read
              </button>
            )}
          </div>

          <div style={{ maxHeight: 340, overflowY: 'auto' }}>
            {!session ? (
              <div style={{ padding: '28px 20px', textAlign: 'center' }}>
                <Bell size={24} style={{ margin: '0 auto 8px', color: 'var(--peach)', opacity: 0.6 }} />
                <strong style={{ display: 'block', color: 'var(--paper)', fontSize: 13, marginBottom: 4 }}>
                  Personalized Alerts
                </strong>
                <p style={{ color: 'var(--muted)', fontSize: 11, lineHeight: 1.5, margin: '0 0 16px' }}>
                  Sign in to receive instant hold warnings, waitlist offers, and confirmed ticket notifications.
                </p>
                <Link
                  href="/login"
                  onClick={() => setOpen(false)}
                  className="coral-button"
                  style={{ width: '100%', justifyContent: 'center', padding: '10px', fontSize: 11 }}
                >
                  <LogIn size={13} /> Sign In to Encore
                </Link>
              </div>
            ) : notifications.length === 0 ? (
              <div style={{ padding: '32px 16px', textAlign: 'center', color: 'var(--muted)', fontSize: 12 }}>
                <CheckCircle2 size={24} style={{ margin: '0 auto 8px', color: 'var(--green)' }} />
                You’re all caught up. No new alerts.
              </div>
            ) : (
              notifications.map(n => (
                <Link
                  key={n.id}
                  href={n.link}
                  onClick={() => {
                    setNotifications(prev => prev.map(item => (item.id === n.id ? { ...item, unread: false } : item)));
                    setOpen(false);
                  }}
                  style={{
                    display: 'block',
                    padding: '14px 16px',
                    borderBottom: '1px solid #202327',
                    background: n.unread ? 'rgba(224, 122, 95, 0.08)' : 'transparent',
                    textDecoration: 'none',
                    transition: 'background 0.2s',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                      {n.type === 'waitlist_offer' ? (
                        <Sparkles size={13} color="var(--coral)" />
                      ) : n.type === 'hold_warning' ? (
                        <Clock size={13} color="var(--peach)" />
                      ) : (
                        <Ticket size={13} color="var(--green)" />
                      )}
                      <strong style={{ color: 'var(--paper)', fontSize: 12, fontWeight: 600 }}>{n.title}</strong>
                    </div>
                    <button
                      type="button"
                      onClick={e => dismiss(n.id, e)}
                      style={{ background: 'transparent', border: 0, color: 'var(--muted)', cursor: 'pointer', padding: 2 }}
                    >
                      <X size={12} />
                    </button>
                  </div>
                  <p style={{ margin: '2px 0 6px', color: '#c0b6af', fontSize: 11, lineHeight: 1.5 }}>{n.message}</p>
                  <span style={{ color: 'var(--muted)', font: '9px var(--mono)', textTransform: 'uppercase' }}>
                    {n.timestamp} · Tap to view pass →
                  </span>
                </Link>
              ))
            )}
          </div>

          <div
            style={{
              padding: '10px 16px',
              borderTop: '1px solid #282b30',
              background: '#131517',
              textAlign: 'center',
            }}
          >
            <Link
              href="/waitlist"
              onClick={() => setOpen(false)}
              style={{
                color: 'var(--peach)',
                font: '10px var(--mono)',
                textTransform: 'uppercase',
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
              }}
            >
              My Waitlists & Preferences <ChevronRight size={12} />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
